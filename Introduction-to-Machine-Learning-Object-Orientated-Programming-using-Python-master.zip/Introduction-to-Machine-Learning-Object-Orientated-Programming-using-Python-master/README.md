# Introduction to Machine Learning & Object-orientated Programming using Python

## Preface 
This workshop is intended to provide an introduction to Machine Learning (ML) and object-orientated programming using Python. Upon completion you will:

* Be familiarized with Python syntax and be able to develop simple classes and functions.
* Have developed your Python programming knowledge and created a linked-list data structure to efficiently store sparse arrays.
* Have used a popular data structures and data analysis tool, Panadas, to automatically extract images and labels from the pre-packaged MNIST database of handwritten digits.
* Have created a custom-data loader for the PyTorch ML library to interface the extracted labels and images.
* Have used the PyTorch ML library to classify handwritten digits using a small-scale Convolutional Neural Network (CNN).

Please clone this Repository using the following command. If you do not already have git installed, it is avaliable here: https://git-scm.com/downloads.

`git clone https://github.com/coreylammie/Introduction-to-Machine-Learning-Object-Orientated-Programming-using-Python && cd Introduction-to-Machine-Learning-Object-Orientated-Programming-using-Python`

## Dependency Installation & Setup
The following dependencies are required for completion of this workshop:

* Python 3.7, pip, and CONDA.
* PyTorch >= 1.0, and torchvision.
* Numpy, Pandas, tensorboard_logger, and Matplotlib.

The open-source Anaconda Distribution can be used to install Python 3.7, pip, and CONDA automatically. Anaconda can be downloaded from https://www.anaconda.com/distribution/ and supports Windows, macOS, and Linux operating systems.

All dependencies can installed by executing the following command in a terminal after successful installation of Python 3.7, pip, and CONDA:

`conda install pytorch-cpu torchvision-cpu -c pytorch && pip install -r requirements.txt`

To open jupyter notebooks execute the following command in a terminal:

`jupyter notebook`

Finally, open *Introduction-to-Machine-Learning-Object-Orientated-Programming-using-Python.ipynb*.


