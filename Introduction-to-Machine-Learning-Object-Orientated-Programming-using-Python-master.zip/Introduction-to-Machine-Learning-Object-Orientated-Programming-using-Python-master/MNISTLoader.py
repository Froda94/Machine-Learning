from torch.utils.data.dataset import Dataset
from torchvision import datasets, transforms
from torch.utils.data.sampler import SubsetRandomSampler
import pandas as pd
import numpy as np
import os
from PIL import Image
import torch
import torch.utils.data.sampler

class MNISTLoader(Dataset):
    def __init__(self, image_path, csv_path, transform=None):
        self.image_path = image_path
        self.to_tensor = transforms.ToTensor()
        self.data_labels = pd.read_csv(csv_path)
        self.labels = np.asarray(self.data_labels.iloc[:, 0])
        self.image_arr = np.asarray(self.data_labels.iloc[:, 1])
        self.data_len = len(self.data_labels.index)
        self.transform = transform

    def __getitem__(self, index):
        self.single_image_label = self.image_arr[index]
        label = self.single_image_label
        img_label = self.labels[index]
        img_as_img = Image.open(label)
        if self.transform is not None:
            img_as_ten = self.transform(img_as_img)
        else:
            img_as_ten = torch.FloatTensor(self.to_tensor(img_as_img))

        return (img_as_ten, img_label)

    def __len__(self):
        return self.data_len
