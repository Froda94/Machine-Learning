import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def loadMNIST(batch_size=1):
    train_loader = torch.utils.data.DataLoader(
        datasets.MNIST('Data', train=True, download=True,
        transform=transforms.Compose([transforms.ToTensor()])),
        batch_size=batch_size, shuffle=False)

    test_loader = torch.utils.data.DataLoader(
        datasets.MNIST('Data', train=False,
        transform=transforms.Compose([transforms.ToTensor()])),
        batch_size=batch_size, shuffle=False)

    return train_loader, test_loader

train_loader, test_loader = loadMNIST()
